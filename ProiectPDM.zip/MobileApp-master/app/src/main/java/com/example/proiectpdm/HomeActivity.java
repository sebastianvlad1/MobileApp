package com.example.proiectpdm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.GridView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
        final GridView gridView = (GridView) findViewById(R.id.gridy);
        gridView.setAdapter(new Adaptery(this));
        gridView.setNumColumns(2);
        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final Intent intent;
                switch (position) {
                    //fiecare case are numarul pozitiei imaginii respective,creezi o activitate noua in caz ca nu e
                    //log out-ul urmeaza sa fie la imaginea 6
                    case 0:
                        intent = new Intent(gridView.getContext(), ActivityOne.class);
                        break;

                    case 1:
                        intent = new Intent(gridView.getContext(), ActivityTwo.class);
                        break;

                    default:
                        intent = new Intent(gridView.getContext(), LoginActivity.class);
                        break;
                }
                startActivity(intent);
            }

        });
    }}



